# Be sure to restart your server when you modify this file.

Quiz::Application.config.session_store :cookie_store, key: '_quiz_session'
