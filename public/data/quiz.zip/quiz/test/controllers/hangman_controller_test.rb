require 'test_helper'

class HangmanControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
