require 'test_helper'

class HangmanHelperTest < ActionView::TestCase
end
