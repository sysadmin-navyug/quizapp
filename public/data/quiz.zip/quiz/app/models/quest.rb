class Quest < ActiveRecord::Base
end
