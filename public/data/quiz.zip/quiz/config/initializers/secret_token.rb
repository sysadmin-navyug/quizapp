# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Quiz::Application.config.secret_key_base = '6088bb42a7bcb6355bb11b11e1e5efdbad7f91644ebd44aa4c23e1603f4b5bdce9b34b4c09ffe191d110a91233651bd740dc26e3ed37186f31d940aae78957f9'
