module HangmanHelper
end
